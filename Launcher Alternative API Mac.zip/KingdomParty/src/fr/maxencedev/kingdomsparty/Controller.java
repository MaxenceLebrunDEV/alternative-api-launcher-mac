package fr.maxencedev.kingdomsparty;

public class Controller {


}
